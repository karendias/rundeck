jQuery(document).on('load.rundeck.page', function () {
    initXKCD()
});
