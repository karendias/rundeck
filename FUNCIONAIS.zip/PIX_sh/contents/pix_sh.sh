#!/bin/bash
echo "Olá PIX, segue retorno do $(hostname)! sou a maquina $1. - \"$2\""
 