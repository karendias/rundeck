#!/usr/bin/php -q

var_palavra=$1

<?

#echo " Informe uma palavra de até 100 Caracteres: ";

    function dia_atual()
    {
        $hoje = getdate();
        switch($hoje["wday"])
        {
            case 0:
            return "Domingo";
            break;
            case 1:
            return "Segunda";
            break;
            case 2:
            return "Terça";
            break;
            case 3:
            return "Quarta";
            break;
            case 4:
            return "Quinta";
            break;
            case 5:
            return "Sexta";
            break;
            case 6:
            return "Sábado";
            break;
        }
    }

    //chamada à função
    $dia = dia_atual();
    echo $dia;


?>