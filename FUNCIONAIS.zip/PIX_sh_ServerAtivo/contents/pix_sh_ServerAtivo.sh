#!/bin/bash
# echo "Olá PIX, segue retorno do $(hostname)! sou a maquina $1. - \"$2\""

 #!/bin/bash<br>
 # Script to add a user to Linux system<br>

search_dir=/opt/jqware/outbox

SERVER=$1
USER=qware
PASS=66C11A22E006AFD9  #criptografado como qwpwd -i -x pix2000#
PASS2=33C3109AAA028CCB #Criptografado como qwpwd -s localhost -P 6785 -u qware -p pix2000 -x pix2000#

FILA=FILATESTE
QWARE_HOME=/opt/jqware/bin

echo " IP/Nome do servidor informado: $1 "

$QWARE_HOME/qwinq -s @option.Servidor@ -P 6785 -u $USER -e $PASS2 -q

if [ $? -eq 0 ]

    then
        printf "${GREEN}Q-WARE SERVER ESTÁ ATIVO! ${NC}\n"
    else
        printf "${RED}ERRO!!! Q-WARE SERVER DESATIVADO ${NC}\n"
fi

echo "  "
